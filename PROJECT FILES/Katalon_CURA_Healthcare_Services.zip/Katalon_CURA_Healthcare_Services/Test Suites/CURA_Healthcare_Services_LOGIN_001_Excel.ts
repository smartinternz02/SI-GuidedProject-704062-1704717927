<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CURA_Healthcare_Services_LOGIN_001_Excel</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>9fa1a3e4-5f3b-47b3-aeb6-4de6e4b48886</testSuiteGuid>
   <testCaseLink>
      <guid>749043ba-c39d-42db-b8b2-64069f518119</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CURA_Healthcare_Services/TC_CHS_LOGIN_001</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>dd633f22-8711-4626-9cb2-2a9bf826a031</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/CURA_Healthcare_Services_LOGIN_001_Excel/CURA_Healthcare Services_LOGIN_001_Excel</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
