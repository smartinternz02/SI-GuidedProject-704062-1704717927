
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "comtestdemo.CURA_Healthcare_Services.CheckDropElementKatalon"(
    	TestObject object	
     , 	String option	) {
    (new comtestdemo.CURA_Healthcare_Services()).CheckDropElementKatalon(
        	object
         , 	option)
}
